def login(user, password):
    if (user == "DGomez" and password == "Ufide123"):
        return True
    else:
        return False