import Ahorcado
import Login_Info
import Funciones
import Archivos
import socket
import MenuPagos
from datetime import  datetime
import Procesos

#Variables
IP = (socket.gethostbyname(socket.gethostname()))
dateTime = datetime.now()
Funciones.greeting()

#Log in
Counter = 0
access = False

while(Counter < 3):
    name = input("Ingrese su nombre: ")
    user = input("Por favor ingrese su usuario: ")
    password = input("Por favor ingrese su contraseña: ")


    if (Login_Info.login(user, password)):
        Funciones.successlogin()
        print("Bienvenido" + " " + name)
        access = True

        #BITACORA
        Archivos.addInfo(str(dateTime), user, "Ingreso Exitoso - IP de registro: " + IP)
        break
    else:
        Funciones.incorrect()
        Counter = Counter+1
        #BITACORA
        Archivos.addInfo(str(dateTime), user, "Ingreso Fracasado - IP de registro: " + IP)

#Menu
if (access):
    option = ""
    Archivos.addInfo(str(dateTime), user, "Menu Principal - IP de registro: " + IP)

    print("Menú\n"
          "1. Transferencias SINPE.\n"
          "2. Recargas telefónicas.\n"
          "3. Pagos de Servicios.\n"
          "4. Ahorcado.\n"
          "5. Salir.\n")
    option = input("Ingrese una opción: ")

    if (option == "1"):
        Procesos.SINPE()
        Procesos.codeGen()
        Funciones.functExit(user)
        #BITACORA
        Archivos.addInfo(str(dateTime), user, "Transferencias SINPE - IP de registro: " + IP)
    elif (option =="2"):
        Procesos.charge()
        Procesos.codeGen()
        Funciones.functExit(user)

        #BITACORA
        Archivos.addInfo(str(dateTime), user, "Recargas telefónicas: " + IP)
    elif (option == "3"):
        MenuPagos.utilities(user)
        # Bitacora
        Archivos.addInfo(str(dateTime), user, "Pagos: " + IP)
    elif (option == "4"):
        Ahorcado.game()
        Funciones.functExit(user)
        # Bitacora
        Archivos.addInfo(str(dateTime), user, "Ahorcado: " + IP)
    elif (option == "5"):
        # Bitacora
        Archivos.addInfo(str(dateTime), user, "Salió del Sistema - IP de registro: " + IP)
        Funciones.farewell()
    else:
        print("Opcion incorrecta, por favor intente de nuevo.")



else:
    Funciones.userlocked()
    Archivos.addInfo(str(dateTime), user, "Usuario Bloqueado - IP de registro: " + IP)




