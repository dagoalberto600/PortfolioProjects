import Procesos
import Funciones
import socket
import Archivos
from datetime import  datetime

#Variables de bitacora
IP = (socket.gethostbyname(socket.gethostname()))
dateTime = datetime.now()
def utilities(user):
    option = ""
    print("Menú\n"
          "1. Pago de Luz.\n"
          "2. Pago de Agua.\n"
          "3. Pago de Internet.\n"
          "4. Salir.\n")
    option = input("Ingrese una opción: ")
    if (option == "1"):
        Procesos.light()
        Procesos.codeGen()
        Funciones.functExit(user)
        #BITACORA
        Archivos.addInfo(str(dateTime), user, "Pago de Luz - IP de registro: " + IP)
    elif (option =="2"):
        Procesos.water()
        Procesos.codeGen()
        Funciones.functExit(user)
        #BITACORA
        Archivos.addInfo(str(dateTime), user, "Pago de agua: " + IP)
    elif (option == "3"):
        Procesos.internet()
        Procesos.codeGen()
        Funciones.functExit(user)

        # BITACORA
        Archivos.addInfo(str(dateTime), user, "Pago de Internet - IP de registro: " + IP)

    elif (option == "4"):
        # Bitacora
        Archivos.addInfo(str(dateTime), user, "Salió del Sistema - IP de registro: " + IP)
        Funciones.farewell()

    else:
        print("Opcion incorrecta, por favor intente de nuevo.")

