
import Funciones
import Archivos
from datetime import  datetime
import socket
dateTime = datetime.now()
IP = (socket.gethostbyname(socket.gethostname()))

def greeting():
    print("Bienvenido al servivio de BANCO Fide")

def farewell():
    print("Gracias por usar el servicio BANCO Fide")


def userlocked():
    print("Alcanzó el maximo de intentos válidos")

def successlogin():
    print("Credenciales Correctos")

def incorrect():
        print("Usuario y/o contraseña inválidos, por favor intente de nuevo")

def functExit(user):
    print("Menú\n"
          "1. Salir.\n")
    Archivos.addInfo(str(dateTime), user, "Menu Principal - IP de registro: " + IP)
    option = input("Ingrese una opción: ")
    if (option == "1"):
        # Bitacora
        Archivos.addInfo(str(dateTime), user, "Salió del Sistema - IP de registro: " + IP)
        Funciones.farewell()

    else:
        print("Opcion incorrecta, por favor intente de nuevo.")