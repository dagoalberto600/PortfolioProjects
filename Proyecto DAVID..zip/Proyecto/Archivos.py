import os

def bankFile (fileName):
    file = open(fileName + ".txt", "w")
    print("Archivo creado")
    file.close()

def addInfo(fechaHora, usuario, proceso):
    file = open("datosBanco.txt", "a")
    file.write(" Hora registro : ")
    file.write(fechaHora)
    file.write(" Usuario : ")
    file.write(usuario)
    file.write(" Accion : ")
    file.write(proceso)
    file.write("\n")
    file.close()





