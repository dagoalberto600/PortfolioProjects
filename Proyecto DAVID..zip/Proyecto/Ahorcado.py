#Juego ahorcado
def game():

     word = ['H','O','L','A']

     tries = 0

     print('Adivina la palabra de 4 letras, ingrese una letra, solo tiene 4 intentos. Buena suerte!\n')
     while(tries <4):
          tries = tries+1
          letter = input("Ingrese la letra: \n")

          for x in range(len(word)):
               if word[x] == letter:
                    word[x] = '0'
     if word[x] == '0':
          print('Gano')
     print(word)


