from numpy import random

#SINPE
def SINPE():
    account = input("Ingrese el numero: ")
    amount = input("Ingrese el monto: ")
    print("Transaccion exitosa para: " + account + "\n"
            "Por un monto de: " + "₡" + amount)
#Recarga
def charge():
    number = input("Digite el numero telefonico a realizar la recarga: ")
    amount_1 = input("Ingrese el monto: ")
    print("Recarga realizada satisfactoriamente a: " + number + "\n"
            "Por un monto de: " + "₡" + amount_1)

#PAGO LUZ
def light():
    nise = input("Ingrese el numero de NISE: ")
    amount = input("Ingrese el monto: ")
    print("Pago exitoso de Luz para: " + nise + "\n"
            "Por un monto de: " + "₡"  + amount)

#PAGO AGUA
def water():
    nise = input("Ingrese el numero de NISE: ")
    amount = input("Ingrese el monto: ")
    print("Pago exitoso de Agua para: " + nise + "\n"
            "Por un monto de: " + "₡"  + amount)

#PAGO INTERNET
def internet():
    nise = input("Ingrese el numero de NISE: ")
    amount = input("Ingrese el monto: ")
    print("Pago exitoso de Internet para: " + nise + "\n"
            "Por un monto de: " + "₡" + amount)

#CODIGO TRANSACCION
def codeGen():
    ran = random.randint(100, size=(5))
    print("Codigo the transaccion: " , ran,"\n")



